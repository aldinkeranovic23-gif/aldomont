POVEZANA POCETNA VERZIJA POSLOVNE APLIKACIJE

Sadrzi prijavu preko Supabase Auth, ucitavanje profila i role te pregled brojaca i tabela ponuda/poslova/klijenata.

Pokretanje:
- Objavi index.html na HTTPS hostingu (npr. Vercel ili Netlify), ili koristi lokalni web server.
- U Supabase Authentication > URL Configuration dodaj adresu aplikacije.
- Email provider mora biti ukljucen.
- Vlasnicki profil mora postojati u public.profiles sa role='owner'.
- Testiraj RLS politike prije unosa stvarnih podataka.

Napomena: ovo jos nije puna produkcijska aplikacija. Ne sadrzi kreiranje/izmjenu zapisa, pozivanje radnika/klijenata ni PDF ponude. Publishable key je namijenjen frontend-u; nikad ne stavljati sb_secret_ ili service_role kljuc u browser.
